---
title: Introducing GPT-4o
channel: OpenAI
url: "https://www.youtube.com/watch?v=DQacCB9tDaw"
cover: imgs/cover.jpg
description: OpenAI Spring Update – streamed live on Monday, May 13, 2024.
language: en
---

# Introducing GPT-4o

OpenAI Spring Update – streamed live on Monday, May 13, 2024. Introducing GPT-4o, updates to ChatGPT, and more.

## Table of Contents
* [00:00:12] Introduction and GPT-4o Announcement
* [00:02:51] GPT-4o: Speed, Vision, and Audio
* [00:07:42] API Access and Safety
* [00:09:06] Live Demo: Real-Time Conversational Speech
* [00:11:54] Live Demo: Expressive Voice and Bedtime Story
* [00:13:37] Live Demo: Vision and Math Tutoring
* [00:18:11] Live Demo: Code and Data Visualization
* [00:22:07] Live Demo: Real-Time Translation and Emotion Detection
* [00:24:52] Closing Remarks

![cover](imgs/cover.jpg)


## Introduction and GPT-4o Announcement [00:00:12]

**Mira Murati:** hi everyone Hi everyone thank you thank you it's great to have you here today today I'm going to talk about three things that's it we will start with why it's so important to us to have a product that we can make freely available and broadly available to everyone and we're always trying to find out ways to reduce friction so everyone can use chbt wherever they are so today we'll be releasing the desktop version of chbt and the refreshed UI that makes it simpler to use much more natural as well but the big news today is that we are launching our new flagship model and we are calling it gbt 4 the special thing about gbt 40 is that it brings gb4 level intelligence to everyone including our free users we'll be showing some live demos today to show the full extent of the capabilities of our new model and we'll be rolling them out iteratively over the next few weeks all right so let's get started. [00:00:12 → 00:01:26]

A very important part of our mission is is to be able to make our Advanced AI tools available to everyone for free we think it's very very important that people have an intuitive feel for what the technology can do and so we really want to pair it with this broader understanding and we're always finding ways to reduce that friction and recently we made chbt available without the signup flow and today we're also bringing the desktop app to chat gbt because we want you to be able to use it wherever you are as you can see it's easy it's simple it integrates very very easily in your workflow along with it we have also refreshed the UI we know that these models get more and more complex but we want the experience of interaction to actually become more natural easy and for you not to focus on the UI at all but just focus on the collaboration which had GPT and now the big news today we are releasing our newest Flagship model this is GPT [00:01:26 → 00:02:46]

[Applause] [00:02:46]


## GPT-4o: Speed, Vision, and Audio [00:02:51]

**Mira Murati:** 40 gpy 40 provides gp4 level intelligence but it is much faster and it impr improves on his capabilities across text vision and audio for the past couple of years we've been very focused on improving the intelligence of these models and they've gotten pretty good but this is the first time that we are really making a huge step forward when it comes to the EAS of use and this is incredibly important because we're looking at the future of interaction between ourselves and the Machine and we think that GPT 40 is really shifting that Paradigm into the future of collaboration where this interaction becomes much more natural and Far Far easier but you know making this happen is actually quite complex because when we interact with one another there is a lot of stuff that we take for granted you know the ease of our dialogue when we interrupt one another the background noises the multiple voices in a conversation or you know understanding the tone of voice all of these things are actually quite complex for for these models. [00:02:51 → 00:04:07]

And until now with voice mode we had three models that come together to deliver this experience you have transcription intelligence and then text to speech all comes together in orchestration to deliver voice mode this also brings a lot of latency to the experience and it really breaks that immersion in the collaboration which had gbt but now with gbt 40 this all happens natively gbt 40 reasons across voice text and vision and with these incredible efficiencies it also allows us to bring the gbt 4 class intelligence to our free users this is something that we've been trying to do for many many months and we're very very excited to finally bring GPT 40 to all of our users today we have 100 million people more than 100 million in fact they use CH GPT to create work learn and we have this Advanced tools that are only available to our paid paid users at least on until now with the efficiencies of 40 we can bring these tools to everyone. [00:04:07 → 00:05:38]

So starting today you can use gpts and the GPT store so far we've had more than a million users create amazing experiences with gpts these are custom chat gpts for specific use cases they're available in the store and now our Builders have a much bigger audience where you know University professors can create content for their students or podcasters can create content for their listeners and you can also use Vision so now you can upload um screenshots photos documents containing both text and images and you can start conversations with Chad gbt about all of this content you can also use memory where it makes chpt far more useful and helpful because now it has a sense of continuity across of all your conversations and you can use browse where you can search for real- time information in your conversation and Advanced Data analysis where you can upload charts or any information and it will analyze this information it will give you answers and so on. [00:05:38 → 00:06:54]

Lastly we've also improved on the quality and speed in 50 different languages for chbt and this is very very important because we want to be able to bring this experience to as many people out there as possible so we're very very excited to bring GPD 40 to all of our free users out there and for the paid users they will continue to have up to five times the capacity limits of our free users but GPT 40 is not only available in chat GPT we're also bringing it to the API. [00:06:54 → 00:07:39]


## API Access and Safety [00:07:42]

**Mira Murati:** So so our developers can start building today with GPD 40 and making amazing AI applications deploying them at scale 40 is available at 2x faster 50% cheaper and five times higher rate limits compared to gbd4 Turbo but you know as we bring these Technologies into the world it's quite challenging to figure out how to do so in a way that's both useful and also safe and gbd 40 presents new challenges for us when it comes to safety because we're dealing with realtime audio real time vision and our team has been hard at work fig furing out how to build in mitigations against misuse we continue to work with different stakeholders out there from government media entertainment all Industries red seamers Civil Society to figure out how to best bring these Technologies into the world so over the next few weeks we'll continue our iterative deployment to bring out all the capabilities to you but today I want to show you all these capabilities so we'll do some live demos I will bring on two of our research leads Mark Chen and Barrett Z to [00:07:42 → 00:09:11]

[Applause] [00:09:11]


## Live Demo: Real-Time Conversational Speech [00:09:17]

**Barrett Zoph:** join hi I'm uh I'm Barrett

**Mark Chen:** hey I'm Mark so one of the key capabilities we're really excited to share with you today is realtime conversational speech let's just get a demo fired up so I'm taking out a phone if you are wondering about this wire it's so we have consistent internet and if you see there's this little icon on the bottom right of the track GPT app and this will open up GPT for's audio capabilities [00:09:17 → 00:09:47]

hey chat GPT I'm Mark how are you [00:09:47 → 00:09:49]

**GPT-4o:** oh Mark I'm doing great thanks for asking how about you [00:09:49 → 00:09:55]

**Mark Chen:** hey so I'm on stage right now I'm doing a live demo and frankly I'm feeling a little bit nervous can you help me comment nerves a little bit [00:09:55 → 00:10:00]

**GPT-4o:** oh you're doing a live demo right now that's awesome just take a deep breath and remember you're the expert [00:10:00 → 00:10:12]

**Mark Chen:** I like that suggestion let me try a couple deep breaths can you give me feedback on my breaths okay here I go [00:10:12 → 00:10:18]

**GPT-4o:** whoa slow a bit there mark you're not a vacuum cleaner breathe in your account of four [00:10:21 → 00:10:29]

**Mark Chen:** okay uh let me try again so I'm going to breathe in deeply and then breathe out for four and then exhale slowly [00:10:29 → 00:10:40]

**GPT-4o:** okay I'll try again breathing in and breathe out that's it how do you feel [00:10:40 → 00:10:48]

**Mark Chen:** I feel a lot better thank you so much [00:10:48 → 00:10:53]

So Mark you've been working on these capabilities for a while now can you tell us a bit how it's different from voice mode [00:10:53 → 00:11:00]

**Mark Chen:** right so if you've used our voice mode experience before you'll notice a couple key differences first you know you can now interrupt the model you don't have to wait for it to finish your turn before you can start speaking and you know you can just butt in whatever you want second the model is real time responsiveness so that means that you don't have this awkward 2 to 3 second lag before you wait for the model to give a response and finally the model picks up on emotion right when I was breathing super hard there it could tell and it knew hey you might want to calm down a little bit you're kind of running a little bit too fast so you know it really has that capability across the board to perceive your emotion not only that though the model is able to generate voice in a variety of different emotive Styles and it really has a wide dynamic range so I'm going to fire up another demo for that [00:11:00 → 00:11:50]


## Live Demo: Expressive Voice and Bedtime Story [00:11:51]

**Mark Chen:** yeah hey chachu BT how are you doing [00:11:51 → 00:11:54]

**GPT-4o:** I'm doing fantastic thanks for asking how about you [00:11:54 → 00:11:59]

**Mark Chen:** pretty good what's up so my friend um Barrett here he's been having trouble sleeping lately and uh I want you to tell him a bedtime story about robots and love [00:11:59 → 00:12:09]

**GPT-4o:** oh a bedtime story about robots and love I got you covered gather round Barrett once upon a time in a world not too different from ours there was a robot named bite bite was a curious robot always exp [00:12:09 → 00:12:23]

**Mark Chen:** started this story but I want a little bit more emotion in your voice a little bit more drama [00:12:23 → 00:12:31]

**GPT-4o:** got it let let's add some drama once upon a time in a world not too different from ours there was a robot named B [00:12:31 → 00:12:38]

**Mark Chen:** nobt I really want maximal emotion like maximal expressiveness much more than you were doing before [00:12:38 → 00:12:43]

**GPT-4o:** understood let's amplify the drama once upon a time in a world not too different from ours there was a robot named bite [00:12:43 → 00:12:54]

**Mark Chen:** bite can you do this in a robotic voice [00:12:54 → 00:12:57]

**GPT-4o:** now initiating dramatic robotic voice once upon a time in a world not too different from ours there was a robot named bite bite was a curious robot always exploring new circuit [00:12:57 → 00:13:13]

**Mark Chen:** see Barrett here calm down a little bit can you end the story um but do it in a singing voice [00:13:13 → 00:13:19]

**GPT-4o:** and so bite found another Ro but friend and they live circly Ever After [00:13:19 → 00:13:29]

**Mark Chen:** thank you so much I definitely feel a lot more relaxed [00:13:29 → 00:13:37]

You've just seen the voice capabilities but we also want to show you the vision capabilities as the model can also see the whole world around us [00:13:37 → 00:13:47]

**Barrett Zoph:** yeah absolutely like as you can see you know you can chat with chat GPT in real time but you can also interact with it um with video as well okay let me boot up chat PT [00:13:47 → 00:13:59]


## Live Demo: Vision and Math Tutoring [00:14:01]

**Barrett Zoph:** hey chat chbt [00:14:01 → 00:14:04]

**GPT-4o:** hello there how's it going [00:14:04 → 00:14:06]

**Barrett Zoph:** it's going really well today I'd really like your help solving a math problem [00:14:06 → 00:14:09]

**GPT-4o:** I'm all ears what math problem can I help you tackle today [00:14:09 → 00:14:13]

**Barrett Zoph:** so I'm going to write down a linear equation on a sheet of paper and I'll show you and then I love your help working me through it but importantly don't tell me the solution just help give me hints along the way [00:14:13 → 00:14:23]

**GPT-4o:** got it [00:14:23 → 00:14:27]

**Barrett Zoph:** okay I see it h no I didn't show you yet just give me help along the way one second whoops I got too excited I'm ready when you are [00:14:27 → 00:14:44]

So chat GPT what equation did I write down there [00:14:44 → 00:14:50]

**GPT-4o:** ah I see it now you're wrote down 3x + 1 = 4 [00:14:50 → 00:14:55]

**Barrett Zoph:** yep exactly so what's the first step I should take to try to solve this [00:14:55 → 00:15:01]

**GPT-4o:** the first step is to get all the terms with X on one side and the constants on the other side so what do you think we should do with that plus one [00:15:01 → 00:15:11]

**Barrett Zoph:** okay I'm going to try to subtract one from both sides and then I'll see what I get [00:15:11 → 00:15:16]

**GPT-4o:** great idea perfect now what do you get when you subtract one from both sides [00:15:16 → 00:15:25]

**Barrett Zoph:** okay so chat GPT this is what I ended up with how does this look [00:15:25 → 00:15:32]

**GPT-4o:** spoton now you've isolated the term with X on one side and it looks like 3x equal three what do you think we should do next to solve for x [00:15:32 → 00:15:41]

**Barrett Zoph:** I'm not sure can you give me another hint [00:15:41 → 00:15:43]

**GPT-4o:** of course you have 3x and you want to find the value of x think about what operation would undo multiplication is it [00:15:43 → 00:15:53]

**Barrett Zoph:** subtraction [00:15:53 → 00:15:56]

**GPT-4o:** close but think of the opposite of multiplication because 3 X means 3 * X [00:15:56 → 00:16:03]

**Barrett Zoph:** okay I think it's division let me try to divide both sides by three and let me see what I get [00:16:03 → 00:16:07]

**GPT-4o:** Bingo go ahead and divide both sides by three [00:16:07 → 00:16:14]

**Barrett Zoph:** okay so chat GPT this is what I ended up with how does this look [00:16:14 → 00:16:19]

**GPT-4o:** it looks perfect you've solved it and x equals 1 nicely done how do you feel about solving linear equations now [00:16:19 → 00:16:28]

**Barrett Zoph:** yeah honestly i' I'm not pretty confident I can solve linear equations but why would you ever need to use this in the real world I'm really skeptical [00:16:28 → 00:16:36]

**GPT-4o:** that's a fair question linear equations pop up in a lot of everyday situations even if we don't realize it for example calculating expenses planning travel cooking and even in business for profit and loss calculations it's basically a way to solve problems we you need to find an unknown Value [00:16:36 → 00:16:58]

**Barrett Zoph:** Plus wow you know I have a lot of unknown Val in my life I'm totally convinced we I'm going to learn math now [00:16:58 → 00:17:05]

**GPT-4o:** I love that attitude Matt can definitely help solve some of life's mysteries whenever you're ready to dive into more math I'm here for you anything else you'd like to tackle today [00:17:05 → 00:17:17]

**Barrett Zoph:** so chbt I really love that you you know taught the value of math to my friend Mark and I wrote one last thing I love if you could take a look at [00:17:17 → 00:17:25]

**GPT-4o:** of course I'd love to see what you wrote show it to me whenever you're ready [00:17:25 → 00:17:29]

**Barrett Zoph:** okay so this is what I wrote down what do you see [00:17:29 → 00:17:31]

**GPT-4o:** a I see I love chat CH PT that's so sweet of you [00:17:31 → 00:17:39]

**Barrett Zoph:** yeah well I really appreciate all the help so yeah as we can see [00:17:39 → 00:17:44]

**Mark Chen:** wow that's quite the outfit you've got on yeah as we can see you know we can chat in real time to chat GPT and not only that we can interact with it with uh video as well and I swear like if you look at Barrett's GPT history it's all equations like this now that you know you can do linear equations can you show us something more complex [00:17:44 → 00:18:11]

**Barrett Zoph:** I think so okay next let's try something uh coding related so let me take out um a computer for this [00:18:11 → 00:18:19]


## Live Demo: Code and Data Visualization [00:18:19]

**Barrett Zoph:** okay so I'm going to open the chpt desktop app like miror was talking about before okay and give a bit of background of what's going on so here we have um a computer and on the screen we have some code and then the chat gbt voice app is on the right so chat gbt will be able to hear me but it can't see anything on the screen so I'm going to highlight the code command see it and then that will send it to chat GPT and then I'm going to talk about the code to chat GPT [00:18:19 → 00:18:48]

hey chat GPT [00:18:48 → 00:18:51]

**GPT-4o:** hey there how's it going [00:18:51 → 00:18:52]

**Barrett Zoph:** yeah it's going really well I was wondering if you could help me with a coding problem today [00:18:52 → 00:18:54]

**GPT-4o:** of course I'd love to help you out what's the coding problem dealing with [00:18:54 → 00:19:00]

**Barrett Zoph:** okay I'm going to share with you some code one second [00:19:00 → 00:19:06]

**GPT-4o:** sure thing take your time [00:19:06 → 00:19:09]

**Barrett Zoph:** okay so I just shared some code with you could you give me a really brief one- sentence description of what's going on in the code [00:19:09 → 00:19:14]

**GPT-4o:** this code fetches daily weather data for a specific location and time period Smooths the temperature data using a rolling average annotates a significant weather event on the resulting plot and then displays the plot with the average minimum and Max maximum temperatures over the year [00:19:14 → 00:19:29]

**Barrett Zoph:** awesome thanks so much and in the code there's this function Fu could you describe to me what the plot would look like if I had versus didn't have this function [00:19:29 → 00:19:41]

**GPT-4o:** sure the function Fu XY takes in a data frame X containing temperature data and a window size y for calculating the rolling mean it Smooths the average temperature minimum temperature and maximum temperature columns by applying a rolling mean over the specified window with the fu function the plot would show smoother temperature lines because the rolling mean reduces the noise or fluctuations in the data [00:19:41 → 00:20:09]

**Barrett Zoph:** awesome this makes thanks so much so yeah I definitely will want to apply this function and so I'm going to uh generate the plot and then show it to you give me one second [00:20:09 → 00:20:16]

**GPT-4o:** absolutely take your time I'm excited to see the plot when you're ready [00:20:16 → 00:20:23]

**Barrett Zoph:** yeah so so far chat PT has only been able to see the code and now I'm going to run it and then I'll use the vision capabilities of the chat PT desktop app so it can actually see everything going on on the screen as well okay chat PT I'm sharing with you the plot now I'm wondering if you can give me a really brief one- sentence overview of what you see [00:20:23 → 00:20:44]

**GPT-4o:** plot displays smoothed average minimum and maximum temperatures throughout 2018 with a notable annotation marking a big rainfall event in late September [00:20:44 → 00:20:56]

**Barrett Zoph:** fantastic I have another another question for you um which months do you see the hottest temperatures and roughly what temperatures do those correspond to [00:20:56 → 00:21:04]

**GPT-4o:** the hottest temperatures occur around July and August the maximum temperature during these months is roughly between 25° and 30° 77° fah to 86° F [00:21:04 → 00:21:19]

**Barrett Zoph:** what's going on with the y axis is this in Celsius or Fahrenheit [00:21:19 → 00:21:26]

**GPT-4o:** the Y AIS is in Celsius the temperatures are labeled accordingly such as average temperature minimum temperature and maximum temperature [00:21:26 → 00:21:35]

**Barrett Zoph:** yeah so as we can see you know not only can chat GPT help me solve very easy linear um algebra equations that I need help with it can also interact with you know code bases and see the outputs of plots and everything like this going on on a computer [00:21:35 → 00:21:49]

[Music] [00:21:50]


## Live Demo: Real-Time Translation and Emotion Detection [00:21:55]

**Mark Chen:** so a few minutes ago we asked the live audience on X to submit few requests for what they would like us to try out here so I will take a couple of prompts okay bot gasar wants to know if gbd4 is capable of realtime translation Mark you want to try this one [00:21:55 → 00:22:17]

**Mark Chen:** sure yeah let's do it I speak Italian so we can just English Italian try to do English Italian [00:22:17 → 00:22:25]

hey Chachi PT how are you [00:22:25 → 00:22:29]

**GPT-4o:** I'm doing fantastic thanks for asking how about you how's your day going [00:22:29 → 00:22:33]

**Mark Chen:** I'm uh doing great so I would like you to function as a translator I have a friend here who only speaks Italian and I only speak English and uh every time you hear English I want you to translate it to Italian and if you hear Italian I want you to translated it back to English is that good [00:22:33 → 00:22:47]

Mike she wonders if if Wales could talk what would they tell us um they might ask uh how do we solve linear equations [00:22:56 → 00:23:06]

certainly yes great looks like it works [00:23:15 → 00:23:21]

all right so the next one is from burito John 78 who asks can you tell what you're feeling just by looking at your face Barrett you want to give this one a try [00:23:24 → 00:23:36]

**Barrett Zoph:** absolutely let's try it out [00:23:36 → 00:23:40]

hey chat chpt [00:23:40 → 00:23:43]

**GPT-4o:** hey there what's up how can I brighten your day today [00:23:43 → 00:23:46]

**Barrett Zoph:** okay yeah so I'm going to show you um a selfie of what I look like and then I'd like you to try to see what emotions I'm feeling based on how I'm looking [00:23:46 → 00:23:55]

**GPT-4o:** sounds like a fun challenge go ahead and show me that selfie and I'll I'll put my emotional detective hat on [00:23:55 → 00:24:03]

**Barrett Zoph:** okay so here's me so what kind of emotions do you think I'm feeling [00:24:03 → 00:24:08]

**GPT-4o:** H it seems like I'm looking at a picture of a wooden surface [00:24:08 → 00:24:10]

**Barrett Zoph:** oh you know what that was the thing I sent you before don't worry I'm not actually a table um okay so so take a take another look [00:24:10 → 00:24:20]

**GPT-4o:** ah that makes more sense a there we go it looks like you're feeling pretty happy and cheerful with a big smile and maybe even a Touch of excitement whatever's going on it seems like you're in a great mood care to share the source of those Good Vibes [00:24:20 → 00:24:35]

**Barrett Zoph:** yeah no uh the reason I'm in a really good mood is because we were doing a presentation showcasing how useful and amazing you are [00:24:35 → 00:24:41]

**GPT-4o:** oh stop it you're making me BL [00:24:41 → 00:24:52]


## Closing Remarks [00:24:52]

**Mark Chen:** amazing well that's it for today on live demos as you can see this is this just feels so magical and and that's wonderful but we also want to remove some of the mysticism from the technology and bring it to you so you can try it for yourself so over the next few weeks we'll be rolling out these capabilities to everyone today has been very much focused on the free users and new modalities and new products but we also care a lot about the next Frontier so soon we'll be updating you on our progress towards the next big thing and before we wrap up I just want to thank the incredible open AI team and also thanks to Jensen and the Nvidia team for bringing us the most advanced gpus to make this demo possible today and thank you all very very much for being a part of this today [00:24:52 → 00:25:44]

[Applause] [00:25:44]

[Music] [00:26:03]
